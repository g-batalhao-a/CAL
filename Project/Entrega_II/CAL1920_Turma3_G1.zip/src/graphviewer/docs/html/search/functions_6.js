var searchData=
[
  ['main',['main',['../_ficha_j_u_n_g_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'FichaJUNG.cpp']]],
  ['myerror',['myerror',['../connection_8cpp.html#ac8b3411018d0e5416c08938b796177ab',1,'connection.cpp']]]
];
