var searchData=
[
  ['sock',['sock',['../class_connection.html#a50ca7c17a64836ca25a1fe9953cc6cf6',1,'Connection']]]
];
