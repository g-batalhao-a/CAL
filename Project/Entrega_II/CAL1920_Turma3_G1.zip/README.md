Dependências:
  - GraphViewer (./src/graphviewer)
  - Mapas	(./Mapas)

Compilação:
A pasta do projeto corresponde a um projeto CLion desenvolvido em Windows. Para compilar é necessário abrir a pasta como um projeto 
  no CLion e executar "Run" para compilar e executar. 